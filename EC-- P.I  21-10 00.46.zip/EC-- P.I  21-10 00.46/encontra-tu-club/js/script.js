// ENCONTRÁ TU CLUB - JavaScript para interacciones sencillas

// Abrir y cerrar el menú en pantallas pequeñas.
const menuBoton = document.getElementById("menuBoton");
const menu = document.getElementById("menu");

if (menuBoton && menu) {
    menuBoton.addEventListener("click", function () {
        menu.classList.toggle("abierto");
    });
}

// FILTRAR CLUBES por nombre, zona y deporte.
const buscarClub = document.getElementById("buscarClub");
const zonaClub = document.getElementById("zonaClub");
const deporteClub = document.getElementById("deporteClub");
const listaClubes = document.getElementById("listaClubes");
const sinClubes = document.getElementById("sinClubes");

function filtrarClubes() {
    if (!listaClubes) return;

    const texto = buscarClub.value.toLowerCase();
    const zona = zonaClub.value;
    const deporte = deporteClub.value;
    const tarjetas = listaClubes.querySelectorAll(".club-card");
    let cantidadVisible = 0;

    tarjetas.forEach(function (tarjeta) {
        const nombre = tarjeta.dataset.nombre.toLowerCase();
        const coincideNombre = nombre.includes(texto);
        const coincideZona = zona === "" || tarjeta.dataset.zona === zona;
        const coincideDeporte = deporte === "" || tarjeta.dataset.deportes.includes(deporte);
        const mostrar = coincideNombre && coincideZona && coincideDeporte;

        tarjeta.classList.toggle("oculto", !mostrar);
        if (mostrar) cantidadVisible++;
    });

    sinClubes.classList.toggle("oculto", cantidadVisible > 0);
}

if (buscarClub && zonaClub && deporteClub) {
    buscarClub.addEventListener("input", filtrarClubes);
    zonaClub.addEventListener("change", filtrarClubes);
    deporteClub.addEventListener("change", filtrarClubes);
}

// FILTRAR DEPORTES por disciplina, zona y categoría.
const filtroDeporte = document.getElementById("filtroDeporte");
const filtroZonaDeporte = document.getElementById("filtroZonaDeporte");
const filtroEdad = document.getElementById("filtroEdad");
const resultadosDeportes = document.getElementById("resultadosDeportes");
const sinDeportes = document.getElementById("sinDeportes");

function filtrarDeportes() {
    if (!resultadosDeportes) return;

    let cantidadVisible = 0;
    const tarjetas = resultadosDeportes.querySelectorAll(".deporte-resultado");

    tarjetas.forEach(function (tarjeta) {
        const coincideDeporte = filtroDeporte.value === "" || tarjeta.dataset.deporte === filtroDeporte.value;
        const coincideZona = filtroZonaDeporte.value === "" || tarjeta.dataset.zona === filtroZonaDeporte.value;
        const coincideEdad = filtroEdad.value === "" || tarjeta.dataset.edad === filtroEdad.value;
        const mostrar = coincideDeporte && coincideZona && coincideEdad;

        tarjeta.classList.toggle("oculto", !mostrar);
        if (mostrar) cantidadVisible++;
    });

    sinDeportes.classList.toggle("oculto", cantidadVisible > 0);
}

if (filtroDeporte && filtroZonaDeporte && filtroEdad) {
    filtroDeporte.addEventListener("change", filtrarDeportes);
    filtroZonaDeporte.addEventListener("change", filtrarDeportes);
    filtroEdad.addEventListener("change", filtrarDeportes);

    // Si se eligió un deporte desde la página de inicio, lo seleccionamos.
    const parametros = new URLSearchParams(window.location.search);
    const deporteElegido = parametros.get("deporte");
    if (deporteElegido) {
        filtroDeporte.value = deporteElegido;
        filtrarDeportes();
    }
}

// FORMULARIO DE CONTACTO: valida los campos y muestra un mensaje.
const formContacto = document.getElementById("formContacto");

if (formContacto) {
    formContacto.addEventListener("submit", function (evento) {
        evento.preventDefault();
        document.getElementById("mensajeContacto").textContent =
            "¡Gracias! El formulario se validó correctamente (demostración escolar).";
        formContacto.reset();
    });
}

// FORMULARIO PARA CONSULTAR INSCRIPCIÓN.
const formInscripcion = document.getElementById("formInscripcion");

if (formInscripcion) {
    formInscripcion.addEventListener("submit", function (evento) {
        evento.preventDefault();
        document.getElementById("mensajeInscripcion").textContent =
            "Consulta registrada en esta demostración. Contactá al club para confirmar la inscripción real.";
        formInscripcion.reset();
    });
}

// REGISTRO de demostración: guarda datos en localStorage.
const formRegistro = document.getElementById("formRegistro");

if (formRegistro) {
    formRegistro.addEventListener("submit", function (evento) {
        evento.preventDefault();

        const cuenta = {
            nombre: document.getElementById("registroNombre").value.trim(),
            correo: document.getElementById("registroEmail").value.trim().toLowerCase(),
            contrasena: document.getElementById("registroPassword").value
        };

        localStorage.setItem("cuentaDemoClub", JSON.stringify(cuenta));
        document.getElementById("mensajeRegistro").textContent =
            "Cuenta de demostración creada. Ahora podés iniciar sesión.";
        formRegistro.reset();
    });
}

// INICIAR SESIÓN: compara los datos guardados.
const formLogin = document.getElementById("formLogin");

if (formLogin) {
    formLogin.addEventListener("submit", function (evento) {
        evento.preventDefault();

        const correo = document.getElementById("loginEmail").value.trim().toLowerCase();
        const contrasena = document.getElementById("loginPassword").value;
        const datosGuardados = localStorage.getItem("cuentaDemoClub");
        const mensaje = document.getElementById("mensajeLogin");

        if (!datosGuardados) {
            mensaje.textContent = "Primero tenés que crear una cuenta de demostración.";
            return;
        }

        const cuenta = JSON.parse(datosGuardados);

        if (correo === cuenta.correo && contrasena === cuenta.contrasena) {
            localStorage.setItem("sesionClub", "activa");
            window.location.href = "perfil.html";
        } else {
            mensaje.textContent = "El correo o la contraseña no coinciden.";
        }
    });
}

// PERFIL: muestra los datos guardados cuando hay una sesión activa.
const perfilNombre = document.getElementById("perfilNombre");

if (perfilNombre) {
    const datosGuardados = localStorage.getItem("cuentaDemoClub");
    const sesionActiva = localStorage.getItem("sesionClub") === "activa";

    if (datosGuardados && sesionActiva) {
        const cuenta = JSON.parse(datosGuardados);
        perfilNombre.textContent = "¡Hola, " + cuenta.nombre + "!";
        document.getElementById("perfilCorreo").textContent = cuenta.correo;
        document.getElementById("perfilAvatar").textContent = cuenta.nombre.charAt(0).toUpperCase();
    } else {
        perfilNombre.textContent = "Todavía no iniciaste sesión";
        document.getElementById("perfilCorreo").textContent =
            "Creá una cuenta o iniciá sesión para ver el perfil de demostración.";
    }
}

// CERRAR SESIÓN.
const cerrarSesion = document.getElementById("cerrarSesion");

if (cerrarSesion) {
    cerrarSesion.addEventListener("click", function () {
        localStorage.removeItem("sesionClub");
        window.location.href = "login.html";
    });
}
